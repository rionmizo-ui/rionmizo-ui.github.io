# きんぎょのさいご 引き継ぎメモ（v23）

## v23 での大きな変更（v22 からの差分。下の v22 の説明より優先）
- 死因 **49種**（突然死35・結末14）。「水槽がせまい」は「巨大化」にまとめた
- 結末の変身・おばけ・ミドリガメ・ナマズ・猫は **assets/*.png のユーザーの絵**（コマ表）。`tools/sheetcut.py` で元の絵から作り直せる（目標幅＝1コマ目の金魚を49ドットに）。`ASSET_INFO`（sprites.js）にコマ数・基準点・`end`（ふだんは最後のコマ）
- 変身の再生は main.js の `SEQ_END` と `playSeq`
- ふれあいの芸15種・しぐさ16種。ミニゲーム3種はお誘い8秒・20〜35秒後から
- 確率：`P`（しぐさ18％・お客さん22％・吸い込み12％）、`TOUCH_P` は v22 の0.75倍
- 確かめ方に追加：`tools/filmall.js`（死に際の通し撮り）、`tools/cardpeek.js`、`tools/cardlist.js`（CARDS.html）、`tools/deathlist.js`（DEATHS.md）。`bot.js` の結果に `stats`（芸・しぐさ・お客さん・イベント・ミニゲームの回数）
- 公開ページ：遊べる https://claude.ai/artifact/WWnRiryJYMEkMP6R1sUob1 ／ 見本 https://claude.ai/artifact/Srbg7TqMBwWp4nFdornG2U ／ デザイン帳 https://claude.ai/artifact/Emi5wjEMyzXi62Qsq8nebD ／ カード帳（CARDS.html）
- 目標：ESP32 に載せても重くならないこと。game.html は 400KB 以内（v23 で 398KB）


## 毎回の約束（チャットを移っても続ける）
作業のたびに、次の4つを必ず渡す。
1. **その版の zip**（`kingyo-vNN.zip`：元のコード・組み立て道具・この文書・変更履歴）
2. **遊べるページ**「きんぎょのさいご（試作）」 https://claude.ai/artifact/WWnRiryJYMEkMP6R1sUob1 を最新版に更新
3. **見本ページ**「金魚の最期 見本」 https://claude.ai/artifact/Srbg7TqMBwWp4nFdornG2U を最新版に更新
4. **何をどう変えたか**をポイントでまとめる（`CHANGELOG.md` にも追記）

> 注：この HANDOFF.md は v18 で作り直したもの。v16 までの元の仕様書（kingyo-v16.zip 内の HANDOFF.md）は
> この作業では受け取れていないため、そちらにある企画の細かい説明はこの文書に入っていない。両方を合わせて使うこと。

## ファイル構成（zip の中）
| パス | 中身 |
|---|---|
| `src/logic.js` | ルールと確率（描画なし）。結末の条件と重み `ENDING_RULES`、突然死の確率 `P` / `TOUCH_P` |
| `src/sprites.js` | ドット絵の描画（金魚・小物・死に際のコマ `DIE` と中割り） |
| `src/main.js` | 演出・入力・音・保存・見本再生 |
| `src/game.template.html` / `src/sample.template.html` | 2つのページのひな形（`<!--SCRIPTS-->` に JS が入る） |
| `tools/build2.js` | 組み立て：`out/game.html`（縮小版＝公開用）と `out/game.full.html`（読みやすい版）を作る。terser が必要 |
| `tools/tune.js` | 結末の重みを自動で合わせるシミュレーション |
| `tools/sim2.js` | 育て方ごとの結末・突然死の割合を見る |
| `tools/bot.js` | 本物のゲームを早送りで自動プレイ（Playwright）。しぐさ・お客さん・ひと休みの回数も数える |
| `tools/deathlist.js` | 文字だけの死因リスト `DEATHS.md` をゲームのデータから作る（条件や確率を変えたら作り直す） |
| `tools/idle_sim2.js` | 放置で起きることにどれくらい出会えるかの時間シミュレーション（ひと休み・成長・事故率の最適化） |
| `game.html` / `sample.html` | 公開している縮小版そのもの |
| `game.full.html` / `sample.full.html` | 同じ中身の読みやすい版 |

### 組み立て方
```
npm i terser@5.31.0
TERSER=./node_modules/terser node tools/build2.js
```

## 遊びの骨組み（v18 時点）
- ボタン：餌・掃除・ふれあい・網。ゲージ15目盛りで満タン → 結末。
- 死因は全部で **49種**：育成途中の突然死 33種＋満タン時の結末 16種（v22 で「こっち側に来た」を削除）。
- お客さん（遊びにくる生き物）6種：タニシ・カニ・エビ・ミドリガメ・ドジョウ・ナマズ（ポップな絵）。カニ・ミドリガメ・ドジョウ・ナマズは訪問1回につき `P.visit`（12%）で事故、事故がなければ「なかよし+1」。ひと休み中は事故なし。
- ひと休み（main.js `REST_EVERY`=3回ごと・`REST_LEN`=9秒）と、のんびり成長（logic.js `GROW_SEC`=6秒ごとにゲージ+1）。値は `tools/idle_sim2.js` で決めた。
- 水槽のかざり：図鑑の数 ÷ 3 の段（最大16段、`S.drawDecor`）。
- ゲージ：おなか＝満タンで色つき・減っていく／ストレス＝たまるほど赤・顔アイコンが怒る。吹き出しは魚の向いている側に出す。
- **結末の決め方**：当てはまる結末（条件が真のもの）の中から重み `w` で抽選。
  - 重みは `tools/tune.js` で「8通りの育て方を混ぜたとき、16種がほぼ同じ回数」になるように調整。
  - まだ図鑑にない結末 ×2、前回と同じ ×0.5、バグった は連打1回ごとに ×(1+回数)。
  - 条件を変えたら **必ず `node tools/tune.js 8 3000` で重みを合わせ直す**（出力の `W=` を `ENDING_RULES` に書き戻す）。
- **突然死の確率**（`P`）：お客さん15%、しぐさ8%、登場2%、餌 各0.4%（5種）、掃除 吸い込み6%／磨きすぎ1.2%、網6%、しぐさ20%、ふれあいは反応ごと（`TOUCH_P`）、イベントは失敗したとき。
- 画面は 160×240、1秒24コマ。泳ぎ8コマ、死に際のコマは中割りつき（`DEATH_FRAMES[k].sub`）。

## 確かめ方
0. `node tools/reach.js ./out/logic.js 1500` → 16の結末すべてに狙って到達できるか。`node tools/reach_real.js out/sample.full.html 0 1` → 50の死因すべてが本物のゲームで札まで行くか。
1. `node tools/tune.js 1 3000` → 結末16種の割合が 5〜7.5% 前後か。
2. `node tools/bot.js $PWD/out/game.html random 3000 16` → エラーなし（`errs` が警告だけ）、`stuck` が0。
3. 見本ページを開いて、107個の水槽がすべて動くか。
